//
// Created by dd on 21/11/2021.
//

#include <stdio.h>
#include <stdlib.h>
#include "List.h"
#include "Student.h"
#include "StudentHandler.h"

void printAllStudentsInfo(List* students){
    printList(students,printInfo);
};
Student* searchStudentById(List* studentList, int id){

};
Student* searchStudentByLastName(List* studentList, char* lastName){

};
