//
// Created by dd on 08/12/2020.
//


#ifndef HUMIDITYDRIVER_H
#define HUMIDITYDRIVER_H

#include <stdint.h>

void humidityDriver_initDriver();
uint8_t humidityDriver_getHumidity();

#endif
